Round trip, exported from datawazi

1. Unzip this folder somewhere, for example C:\datawazi\Round trip\
2. Open Round trip.pbip in Power BI Desktop (it needs the Power BI Project preview feature on older versions).
3. If you unzipped it anywhere else: Transform data > Edit parameters > DataFolder, and set it to the full
   path of the data folder in this project, ending with a backslash. Then click Refresh.
4. To get a single .pbix: File > Save as > Power BI file (.pbix).

The model has 4 measures written in DAX, its relationships and the Date table (marked as a date
table). The data folder holds each table as a Parquet file: the clean data, after datawazi's steps.
